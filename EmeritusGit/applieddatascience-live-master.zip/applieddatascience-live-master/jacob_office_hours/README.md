# Emeritus Applied Data Science

*Jacob's Office Hours Materials*

- [Week 3](week_3/)
